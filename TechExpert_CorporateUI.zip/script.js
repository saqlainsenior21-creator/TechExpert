
document.getElementById("themeToggle")?.addEventListener("click", () => {
    document.body.classList.toggle("dark");
});

// Example dynamic device loader
const devices = [
  { name: "Samsung S21", status: "Online" },
  { name: "iPhone 13", status: "Online" },
  { name: "Pixel 7", status: "Offline" },
];

const list = document.getElementById("deviceList");
if (list) {
  devices.forEach(d => {
    const div = document.createElement("div");
    div.className = "card shadow hover-up";
    div.innerHTML = `<h3>${d.name}</h3><p>Status: ${d.status}</p>`;
    list.appendChild(div);
  });
}
