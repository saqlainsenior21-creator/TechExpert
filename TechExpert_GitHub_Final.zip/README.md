# TechExpert — GitHub Pages Ready (Root Deployment)

This repository is prepared for GitHub Pages deployment from the **root** (Option A).

## How to publish
1. Create a repository named `TechExpert` under GitHub user **saqlainsenior21**.
2. Upload all files in this ZIP to the repository root (do not put them inside a subfolder).
3. In GitHub: Settings → Pages → Source → Branch: `main` (or `master`) and Folder: `/ (root)`.
4. Save and wait ~30-60s for the site to publish.

## Demo credentials (frontend-only demo)
- username: **admin**
- password: **admin123'

## Notes
- USB redirector, ADB agent and backend services are simulated or require additional setup (see previous README). This static deploy is intended for demo / GitHub Pages hosting.
