/* Central site JS for demo auth, devices and simple data */
document.addEventListener('DOMContentLoaded', ()=>{
  // simple demo login
  const loginForm = document.getElementById('loginForm');
  if(loginForm){
    loginForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const u = document.getElementById('username').value;
      const p = document.getElementById('password').value;
      if(u==='admin' && p==='admin123'){
        localStorage.setItem('te_access','demo-token');
        window.location.href = 'dashboard.html';
      } else { document.getElementById('msg').textContent = 'Invalid credentials'; }
    });
  }

  // load devices.json if present
  const deviceList = document.getElementById('device-list');
  if(deviceList){
    fetch('devices.json').then(r=>r.json()).then(data=>{
      const all = [...(data.android||[]),...(data.ios||[])];
      const total = all.length;
      const totalDevicesEl = document.getElementById('totalDevices');
      if(totalDevicesEl) totalDevicesEl.textContent = total;
      const html = all.map(d=>`<div class="card"><h4>${d.name}</h4><p>${d.manufacturer||''} — ${d.android_version||d.ios_version||''}</p><p>Status: ${d.status||'N/A'}</p></div>`).join('');
      deviceList.innerHTML = html;
    }).catch(()=>{ deviceList.innerHTML = '<p>No devices data found.</p>'; });
  }
});
