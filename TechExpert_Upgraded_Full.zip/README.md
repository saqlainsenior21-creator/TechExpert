# TechExpert - Upgraded Project

This package contains a fully-featured demo of TechExpert Remote Device Management & Assistance.
It includes:
- Frontend (HTML/CSS/JS dashboard)
- Secure simulated MDM backend (server.js)
- USB redirector broker (usb-redirector-server.js)
- USB agent example (usb-agent.js)
- USB WebSocket client demo (usb_ws_client.html)
- Local device data (devices.json), commands.json, users.json (file-based)
- README and instructions

This is a demo and requires Node.js to run backend components. See README_USB.md for details.
