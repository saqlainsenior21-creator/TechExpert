# USB Redirector Demo

See usb-redirector-server.js, usb-agent.js and usb_ws_client.html for a demo USB redirector system.
Run broker: `node usb-redirector-server.js`
Run agent on machine with USB: `BROKER=ws://broker:9000/ws DEVICE_ID=device1 node usb-agent.js`
Open usb_ws_client.html in browser to connect as a client.
