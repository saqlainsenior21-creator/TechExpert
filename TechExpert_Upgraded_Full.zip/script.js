/* Main site script: auth, devices, USB features (demo) */

// --- Auth helpers ---
function getToken(){ return localStorage.getItem('accessToken') || null; }
function requireLogin(){ if(!getToken()){ window.location.href='login.html'; } }

// --- Devices ---
async function loadDevices() {
  // Try backend first; fallback to local devices.json if not available
  try {
    const token = getToken();
    const headers = token ? { Authorization: 'Bearer ' + token } : {};
    const res = await fetch('/devices', { headers });
    if (res.ok) {
      const data = await res.json();
      renderDevices(data);
      return;
    }
  } catch(e){ /* ignore */ }

  // Fallback: load local devices.json
  try {
    const r = await fetch('devices.json');
    const data = await r.json();
    renderDevices({ android: data.android || [], ios: data.ios || [] });
  } catch(e){ console.error('No devices available', e); }
}

function escapeHtml(s){ return String(s||'').replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }

function renderDevices(data){
  const list = document.getElementById('device-list');
  if(!list) return;
  const devices = [...(data.android||[]),(...(data.ios||[]))];
  if(devices.length===0){ list.innerHTML='<p>No devices.</p>'; return; }
  list.innerHTML = devices.map(d=>`
    <div class="card">
      <h3>${escapeHtml(d.name||d.model||'Unknown')}</h3>
      <p><strong>Manufacturer:</strong> ${escapeHtml(d.manufacturer||'')}</p>
      <p><strong>OS:</strong> ${escapeHtml(d.android_version||d.ios_version||'')}</p>
      <p><strong>Status:</strong> ${escapeHtml(d.status||'')}</p>
      <div><button class="btn" onclick="openDevice('${d.id||d.name}')">Open</button></div>
    </div>
  `).join('');
}

function openDevice(id){ alert('Open device: '+id + ' (UI placeholder)'); }

// --- USB features (WebUSB) ---
let monitored=false, monitorInterval=null, lastDevices=[];
function safeText(s){ return String(s).replace(/[<>]/g,''); }

async function scanUSBDevices(){
  const tbody = document.getElementById('usb-device-tbody');
  tbody.innerHTML = '<tr><td colspan="5">Requesting device access...</td></tr>';
  try{
    const device = await navigator.usb.requestDevice({ filters: [] });
    await device.open().catch(()=>{});
    lastDevices=[device];
    tbody.innerHTML = buildDeviceRow(device);
  }catch(err){
    tbody.innerHTML = '<tr><td colspan="5">No device selected or WebUSB blocked.</td></tr>';
    console.warn('scanUSBDevices:', err);
  }
}

async function refreshUSBDevices(){
  const tbody = document.getElementById('usb-device-tbody');
  tbody.innerHTML = '<tr><td colspan="5">Refreshing device list...</td></tr>';
  try{
    const devices = await navigator.usb.getDevices();
    lastDevices = devices;
    if(!devices || devices.length===0){ tbody.innerHTML = '<tr><td colspan="5">No USB devices available.</td></tr>'; return; }
    tbody.innerHTML = devices.map(buildDeviceRow).join('');
  }catch(err){
    tbody.innerHTML = '<tr><td colspan="5">Error reading devices (browser unsupported).</td></tr>';
    console.error(err);
  }
}

function buildDeviceRow(device){
  const id = safeText(device.serialNumber || device.productId || device.vendorId || 'unknown');
  const product = safeText(device.productName || 'Unknown');
  const vendor = safeText(device.vendorId || '0x' + (device.vendorId||0).toString(16));
  const pid = safeText(device.productId || '0x' + (device.productId||0).toString(16));
  return `
    <tr>
      <td>${id}</td>
      <td>${product}</td>
      <td>${vendor}</td>
      <td>${pid}</td>
      <td>
        <button class="btn" onclick="openExplorer('${id}')">Explore</button>
        <button class="btn" onclick="pullLogs('${id}')">Pull Logs</button>
        <button class="btn" onclick="forwardDevice('${id}')">Forward</button>
      </td>
    </tr>
  `;
}

function toggleMonitoring(){
  monitored = !monitored;
  const btn = document.getElementById('monitor-btn');
  btn.textContent = monitored ? 'Stop Monitoring' : 'Start Monitoring';
  if(monitored){ monitorInterval = setInterval(refreshUSBDevices,3000); } else { clearInterval(monitorInterval); monitorInterval=null; }
}

function openExplorer(id){
  document.getElementById('usb-explorer').style.display='block';
  const fileList = document.getElementById('file-list');
  fileList.innerHTML = '<ul><li>/sdcard/</li><li>/sdcard/DCIM/</li><li>/sdcard/Logs/</li></ul>';
}

function closeExplorer(){ document.getElementById('usb-explorer').style.display='none'; }

async function pullLogs(id){
  const status = document.getElementById('forward-status');
  status.textContent = 'Requesting logs for ' + id + ' (simulated)...';
  setTimeout(()=> status.textContent = 'Logs pulled (simulated).',1500);
}

function forwardDevice(id){
  document.getElementById('forward-target').value = 'ws://localhost:9000/device/' + id;
  document.getElementById('forward-status').textContent = '';
}

async function startRemoteForward(){
  const target = document.getElementById('forward-target').value.trim();
  const status = document.getElementById('forward-status');
  if(!target){ status.textContent = 'Enter a target address to forward to.'; return; }
  status.textContent = 'Starting remote forward to ' + target + ' (simulated)...';
  setTimeout(()=> status.textContent = 'Remote forward active (simulation).',1200);
}

// try refresh on load
if(typeof navigator !== 'undefined' && navigator.usb && typeof navigator.usb.getDevices === 'function'){
  refreshUSBDevices().catch(()=>{});
}

// Auto-load devices on device page
document.addEventListener('DOMContentLoaded', ()=>{ if(document.getElementById('device-list')) loadDevices(); });
