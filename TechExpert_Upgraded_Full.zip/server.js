/* server.js - Secure simulated MDM backend (Node.js + Express)
   This is the secure backend referenced by the frontend. It uses file-based storage for demo purposes.
*/
import express from "express";
import fs from "fs";
import path from "path";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import bcrypt from "bcryptjs";

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || "CHANGE_THIS_ACCESS_SECRET";
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "CHANGE_THIS_REFRESH_SECRET";
const DEVICE_REPORT_KEY = process.env.DEVICE_REPORT_KEY || "CHANGE_DEVICE_REPORT_KEY";
const DATA_DIR = process.env.DATA_DIR || path.resolve("./");

const DEVICES_FILE = path.join(DATA_DIR, "devices.json");
const COMMANDS_FILE = path.join(DATA_DIR, "commands.json");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const TOKENS_FILE = path.join(DATA_DIR, "refresh_tokens.json");

function ensureFile(filePath, defaultObj) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultObj, null, 2));
  }
}
ensureFile(COMMANDS_FILE, { commands: [] });
ensureFile(USERS_FILE, { users: [] });
ensureFile(TOKENS_FILE, { refreshTokens: [] });
ensureFile(DEVICES_FILE, { android: [], ios: [] });

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(rateLimit({ windowMs: 15*60*1000, max: 200 }));

function readJson(filePath){ try{ return JSON.parse(fs.readFileSync(filePath,"utf-8")); }catch(e){ return null; } }
function writeJson(filePath,obj){ fs.writeFileSync(filePath, JSON.stringify(obj,null,2)); }

function appendCommand(command){
  const data = readJson(COMMANDS_FILE) || { commands: [] };
  data.commands.unshift(command);
  writeJson(COMMANDS_FILE, data);
}

function updateCommandStatus(cmdId, status, result=null){
  const data = readJson(COMMANDS_FILE) || { commands: [] };
  const cmd = data.commands.find(c=>c.id===cmdId);
  if(!cmd) return null;
  cmd.status = status;
  if(result) cmd.result = result;
  cmd.updated_at = new Date().toISOString();
  writeJson(COMMANDS_FILE, data);
  return cmd;
}

function generateAccessToken(user){ return jwt.sign({ username:user.username, role:user.role }, JWT_ACCESS_SECRET, { expiresIn: "15m" }); }
function generateRefreshToken(user){
  const token = jwt.sign({ username:user.username, role:user.role }, JWT_REFRESH_SECRET, { expiresIn: "7d" });
  const data = readJson(TOKENS_FILE) || { refreshTokens: [] };
  data.refreshTokens.push({ token, username: user.username, created_at: new Date().toISOString() });
  writeJson(TOKENS_FILE, data);
  return token;
}
function revokeRefreshToken(token){ const data = readJson(TOKENS_FILE) || { refreshTokens: [] }; data.refreshTokens = data.refreshTokens.filter(t=>t.token!==token); writeJson(TOKENS_FILE, data); }
function isRefreshTokenValid(token){ const data = readJson(TOKENS_FILE) || { refreshTokens: [] }; return data.refreshTokens.some(t=>t.token===token); }

function verifyAccessToken(req,res,next){
  const header = req.headers["authorization"]||"";
  const token = header.replace("Bearer ","");
  if(!token) return res.status(401).json({ error: "No token provided" });
  jwt.verify(token, JWT_ACCESS_SECRET, (err, decoded)=>{ if(err) return res.status(401).json({ error: "Invalid or expired token" }); req.user = decoded; next(); });
}
function requireRole(role){ return (req,res,next)=>{ if(!req.user||!req.user.role) return res.status(403).json({ error: "Role required" }); if(req.user.role!==role && req.user.role!=="admin") return res.status(403).json({ error: "Insufficient permissions" }); next(); }; }

function findUser(username){ const data = readJson(USERS_FILE) || { users: [] }; return data.users.find(u=>u.username===username); }
async function createUser({username,password,role="viewer"}){ const data = readJson(USERS_FILE) || { users: [] }; if(data.users.some(u=>u.username===username)) throw new Error("User already exists"); const hashed = await bcrypt.hash(password,10); const user = { id: uuidv4(), username, password: hashed, role, created_at: new Date().toISOString() }; data.users.push(user); writeJson(USERS_FILE,data); return user; }

(async function ensureAdmin(){
  const data = readJson(USERS_FILE) || { users: [] };
  if(!data.users || data.users.length===0){
    await createUser({ username: "admin", password: "admin123", role: "admin" });
    console.log("Default admin created: admin / admin123 (change immediately)");
  }
})();

// Routes
app.get("/health",(req,res)=>res.json({ status:"ok", ts: new Date().toISOString() }));

app.post("/auth/register", verifyAccessToken, requireRole("admin"), async (req,res)=>{
  const { username, password, role } = req.body;
  if(!username||!password) return res.status(400).json({ error: "username and password required" });
  try{ const user = await createUser({ username, password, role }); res.json({ id:user.id, username:user.username, role:user.role }); } catch(e){ res.status(400).json({ error: e.message }); }
});

app.post("/auth/login", async (req,res)=>{
  const { username, password } = req.body;
  if(!username||!password) return res.status(400).json({ error: "username and password required" });
  const user = findUser(username);
  if(!user) return res.status(401).json({ error: "Invalid credentials" });
  const match = await bcrypt.compare(password, user.password);
  if(!match) return res.status(401).json({ error: "Invalid credentials" });
  const accessToken = generateAccessToken(user);
  const refreshToken = generateRefreshToken(user);
  res.json({ accessToken, refreshToken, role: user.role });
});

app.post("/auth/refresh",(req,res)=>{
  const { refreshToken } = req.body;
  if(!refreshToken) return res.status(400).json({ error: "refreshToken required" });
  if(!isRefreshTokenValid(refreshToken)) return res.status(401).json({ error: "Invalid refresh token" });
  jwt.verify(refreshToken, JWT_REFRESH_SECRET, (err, decoded)=>{ if(err) return res.status(401).json({ error: "Invalid refresh token" }); const user = findUser(decoded.username); if(!user) return res.status(401).json({ error: "User not found" }); const accessToken = generateAccessToken(user); res.json({ accessToken }); });
});

app.post("/auth/logout",(req,res)=>{ const { refreshToken } = req.body; if(!refreshToken) return res.status(400).json({ error: "refreshToken required" }); revokeRefreshToken(refreshToken); res.json({ status: "ok" }); });

app.get("/devices", verifyAccessToken, (req,res)=>{
  const data = readJson(DEVICES_FILE) || { android: [], ios: [] };
  const android = data.android || [];
  const ios = data.ios || [];
  res.json({ android, ios });
});

app.post("/device/:id/command", verifyAccessToken, requireRole("support"), (req,res)=>{
  const deviceId = req.params.id;
  const { action, payload } = req.body;
  if(!action) return res.status(400).json({ error: "No action provided" });
  const command = { id: uuidv4(), device_id: deviceId, action, payload: payload||null, status: "queued", created_by: req.user.username, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), result: null };
  appendCommand(command);
  setTimeout(()=>{ updateCommandStatus(command.id,"sent"); setTimeout(()=>{ updateCommandStatus(command.id,"delivered"); setTimeout(()=>{ updateCommandStatus(command.id,"completed",{ message: "OK (simulated)", ts: new Date().toISOString() }); },2000+Math.random()*3000); },1000+Math.random()*2000); },500+Math.random()*1000);
  res.json({ id: command.id, status: command.status });
});

app.post("/device/:id/report",(req,res)=>{
  const key = req.headers["x-device-key"] || "";
  if(key !== process.env.DEVICE_REPORT_KEY && key !== "") return res.status(401).json({ error: "Invalid device report key" });
  const deviceId = req.params.id;
  const report = req.body || {};
  try{
    const data = readJson(DEVICES_FILE) || { android: [], ios: [] };
    const all = [...(data.android||[]),...(data.ios||[])];
    const idx = all.findIndex(d=>String(d.id)===String(deviceId));
    if(idx>=0){
      const device = all[idx];
      device.last_seen = new Date().toISOString();
      device.status = report.status || device.status || "Online";
      device.simulated_metrics = report.metrics || device.simulated_metrics || {};
      const android = (data.android||[]).map(d=>(String(d.id)===String(deviceId)?device:d));
      const ios = (data.ios||[]).map(d=>(String(d.id)===String(deviceId)?device:d));
      writeJson(DEVICES_FILE,{ android, ios });
    }
  }catch(e){ console.error("Device report update failed:", e); }
  res.json({ status: "report accepted (simulation)" });
});

app.get("/commands", verifyAccessToken, requireRole("support"), (req,res)=>{ const data = readJson(COMMANDS_FILE) || { commands: [] }; res.json(data); });

app.post("/android/push", verifyAccessToken, requireRole("support"), (req,res)=>{ const { device_id, payload } = req.body; console.log("[SIM] Android push to", device_id, payload); res.json({ status: "simulated_push_sent", platform: "android" }); });

app.post("/ios/push", verifyAccessToken, requireRole("support"), (req,res)=>{ const { device_id, payload } = req.body; console.log("[SIM] iOS push to", device_id, payload); res.json({ status: "simulated_push_sent", platform: "ios" }); });

app.get("/health",(req,res)=>res.json({ status:"ok", ts: new Date().toISOString() }));

app.listen(PORT, ()=>console.log(`Secure simulated MDM backend running on port ${PORT}`));
