/* usb-agent.js - runs on machine with USB access, registers with broker and can run adb commands */
import WebSocket from "ws";
import { spawn } from "child_process";

const BROKER = process.env.BROKER || "ws://localhost:9000/ws";
const DEVICE_ID = process.env.DEVICE_ID || "device1";

const ws = new WebSocket(BROKER);

ws.on("open", ()=>{ console.log("Connected to broker"); ws.send(JSON.stringify({ type: "agent_register", deviceId: DEVICE_ID })); });

ws.on("message", (msg)=> {
  try {
    const parsed = JSON.parse(msg.toString());
    if (parsed.type === "agent_ack") console.log("Registered at broker for", parsed.deviceId);
    if (parsed.type === "client_connected") console.log("Client connected to this device");
    if (parsed.type === "control") {
      console.log("Control command:", parsed.command);
      if (parsed.command === "pull_logs") {
        const p = spawn("adb", ["logcat", "-d"]);
        p.stdout.on("data", (chunk)=> { ws.send(chunk); });
        p.on("close", ()=> ws.send(JSON.stringify({ type: "control_result", result: "logs_sent" })));
      }
    }
  } catch(e) {
    // binary data
  }
});

ws.on("close", ()=>console.log("Disconnected from broker"));
ws.on("error", (e)=>console.error("Broker error", e));
