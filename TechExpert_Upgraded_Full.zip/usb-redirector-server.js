/* usb-redirector-server.js - simple WebSocket broker for demo USB forwarding */
import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

const agents = new Map();
const clients = new Map();

wss.on("connection", (ws) => {
  ws.on("message", (msg) => {
    try {
      const parsed = JSON.parse(msg.toString());
      if (parsed.type === "agent_register") {
        const { deviceId } = parsed;
        agents.set(deviceId, ws);
        ws.deviceId = deviceId;
        ws.send(JSON.stringify({ type: "agent_ack", deviceId }));
        return;
      }
      if (parsed.type === "client_connect") {
        const { deviceId } = parsed;
        const agent = agents.get(deviceId);
        if (!agent) { ws.send(JSON.stringify({ type: "error", message: "No agent for device" })); return; }
        clients.set(ws, { deviceId });
        ws.send(JSON.stringify({ type: "client_ack", deviceId }));
        agent.send(JSON.stringify({ type: "client_connected", deviceId }));
        return;
      }
      if (parsed.type === "control") {
        const { deviceId, command } = parsed;
        const agent = agents.get(deviceId);
        if (agent) agent.send(JSON.stringify({ type: "control", command }));
        return;
      }
      ws.send(JSON.stringify({ type: "echo", payload: parsed }));
    } catch (e) {
      if (ws.deviceId && agents.get(ws.deviceId) === ws) {
        for (const [clientSocket, info] of clients.entries()) {
          if (info.deviceId === ws.deviceId && clientSocket.readyState === 1) clientSocket.send(msg);
        }
      } else {
        const info = clients.get(ws);
        if (info) {
          const agent = agents.get(info.deviceId);
          if (agent && agent.readyState === 1) agent.send(msg);
        }
      }
    }
  });

  ws.on("close", () => {
    if (ws.deviceId) { agents.forEach((s,id)=>{ if(s===ws) agents.delete(id); }); }
    if (clients.has(ws)) clients.delete(ws);
  });
});

app.get("/status", (req,res) => res.json({ agents: Array.from(agents.keys()), clients: clients.size }));

const PORT = process.env.PORT || 9000;
server.listen(PORT, ()=>console.log(`USB redirector broker running on port ${PORT}`));
